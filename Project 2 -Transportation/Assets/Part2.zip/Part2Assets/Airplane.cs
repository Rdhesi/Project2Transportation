using UnityEngine;
using System.Collections;

public class Airplane {
	public int x, y;
	public int cargo, cargoCapacity;
	public bool active;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
