﻿using UnityEngine;
using System.Collections;

public class CubeBehavior : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	//Called when something is clicked on
	void OnMouseDown () {

		foreach (GameObject oneCube in GameController.allCubes) {
			oneCube.GetComponent<Renderer>().material.color = Color.white;
		}

		GetComponent<Renderer>().material.color = Color.red;
	}

	// Update is called once per frame
	void Update () {
	
	}
}
