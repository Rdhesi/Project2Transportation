﻿using UnityEngine;
using System.Collections;

public class GameController : MonoBehaviour {
	public GameObject cubePrefab;
	public static int numCubes = 16;
	public static GameObject[] allCubes=new GameObject[numCubes];
	// Use this for initialization
	void Start () {

		for (int i = 0; i < numCubes; i++) {
			allCubes[i]=(GameObject) Instantiate(cubePrefab, new Vector3(i*2 - 15, 0, 10), Quaternion.identity);		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
